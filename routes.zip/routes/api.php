<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('login', [ApiController::class, 'login']);
Route::get('products/{id?}', [ApiController::class, 'getproducts']);
Route::get('mastercases/{id?}', [ApiController::class, 'getmastercases']);
Route::get('mcproducts/{mcid}', [ApiController::class, 'getmcproducts']);
Route::get('warehouses/{id?}', [ApiController::class, 'getwarehouses']);
Route::get('pickorders/pending/{transaction?}', [ApiController::class, 'getpendingpickorders']);
Route::get('pickorders/confirmed/{transaction?}', [ApiController::class, 'getconfirmedpickorders']);
Route::get('binlocation/{id}', [ApiController::class, 'getbinlocation']); 
Route::get('confirmpo/{id}/{user}', [ApiController::class, 'confirmpickorder']);  
Route::get('getmcpro/{id}', [ApiController::class, 'getmastercase_products']); 
Route::get('recievedproducts/{id?}', [ApiController::class, 'getrecieved']);
Route::get('assignedcheckin', [ApiController::class, 'getassignedcheckin']);
Route::get('unassignedcheckin', [ApiController::class, 'getunassignedcheckin']);
Route::get('assignedcheckinstatus/{id}', [ApiController::class, 'getassignedcheckinstatus']);
Route::get('checkedin/{palletno}/{user}', [ApiController::class, 'checkedin']);

Route::get('racks/{warehouse}', [ApiController::class, 'getrackinfo']);
Route::get('binlocationbyrack/{rack}', [ApiController::class, 'getbinlocationbyrack']);

Route::post('startcyclecount', [ApiController::class, 'startcyclecount']);
Route::get('markcyclecount/{id}/{palletno}', [ApiController::class, 'markcyclecount']);
Route::get('cyclecountlocations/{ccid}', [ApiController::class, 'cyclecountlocations']);
Route::get('cyclecountclose/{ccid}', [ApiController::class, 'cyclecountclose']);
Route::get('cyclecountcancel/{ccid}', [ApiController::class, 'cyclecountcancel']);

Route::get('transfers/{id?}', [ApiController::class, 'gettransfers']);

