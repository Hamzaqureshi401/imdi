<!DOCTYPE html>
<html>
<head>
    <title>Your Password</title>
</head>
<body>
    <h1>Your Password</h1>
    <p>Here is your system generated password: <strong>{{ $password }}</strong></p>
    
</body>
</html>