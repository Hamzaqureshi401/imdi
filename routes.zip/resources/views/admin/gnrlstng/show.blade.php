@extends('layouts.admin.app')

@section('header')

@endsection

@section('title')
 User Detail
@endsection

@section('content')
@endsection

@section('footer')
@endsection