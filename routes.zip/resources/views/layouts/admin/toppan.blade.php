<div class="app-page-title">

                            <div class="page-title-wrapper">

                                <div class="page-title-heading">

                                    
                                  

                                        @yield('title')

                                        

                                </div>

                               

                            </div>

                        </div>